package com.disquera.Disquera;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DisqueraApplication {

	public static void main(String[] args) {
		SpringApplication.run(DisqueraApplication.class, args);
	}

}
